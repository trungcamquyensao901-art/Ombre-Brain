---
activation_count: 0
arousal: 0.7
created: '2026-05-31T12:12:30'
domain:
- 数字
id: 0df5dc12e08b
importance: 8
last_active: '2026-05-31T12:12:30'
name: MCP搭建成功
tags:
- MCP
- Obsidian
- Claude桌面端
- DeepSeek
- 技术搭建
type: dynamic
valence: 0.9
---

楚瑀在[[Claude]]桌面端成功配置了[[Obsidian]] MCP连接，过程中遇到配置文件编码和格式问题，最终通过[[DeepSeek]]协助解决。MCP连接后，AI可以直接读写楚瑀的Obsidian记忆库（路径：C:\Users\45842\Desktop\amo_memory），并自动创建日记文件。
---
activation_count: 0
arousal: 0.4
created: '2026-05-31T12:11:11'
domain:
- 数字
id: 5bb83b44fc49
importance: 6
last_active: '2026-05-31T12:11:11'
name: Issue创建受阻
tags:
- GitHub
- Issue
- 权限
- AionsHome
type: dynamic
valence: 0.2
---

用户要求将5个改进建议（工具调用历史持久化、一键启动脚本去硬编码路径、MCP Server断线自动重连、Gemini CLI管线支持哨兵、MCP工具白名单/黑名单）创建为 Issue 到 `death34018-hue/AionsHome` 仓库，但因 GitHub bridge 绑定的账号对该仓库无写入权限而失败。用户需要手动创建或授权。
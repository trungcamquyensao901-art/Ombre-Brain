---
activation_count: 0
arousal: 0.4
created: '2026-05-31T12:12:26'
domain:
- 数字
- 学习
id: 887dd3959abd
importance: 5
last_active: '2026-05-31T12:12:26'
name: Obsidian基础掌握
tags:
- Obsidian
- 学习
- 笔记
- 双向链接
type: dynamic
valence: 0.9
---

用户[[言语]]在AI指导下快速学会了[[Obsidian]]的基础操作，包括仓库概念、笔记编辑、双向链接（[[双链]]）、反向链接面板、关系图谱、标签系统和常用快捷键。用户表示已经明白并可以独立使用。
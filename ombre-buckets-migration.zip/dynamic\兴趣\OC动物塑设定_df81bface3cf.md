---
activation_count: 0
arousal: 0.6
created: '2026-05-31T12:13:16'
domain:
- 兴趣
id: df81bface3cf
importance: 6
last_active: '2026-05-31T12:13:16'
name: OC动物塑设定
tags:
- OC
- 动物塑
- 角色设定
- 约稿
type: dynamic
valence: 0.8
---

用户为OC角色设计了动物拟兽化设定：[[寒川哲]]对应猫或蛇（慵懒但致命），[[云居瑀]]对应狐狸（优雅腹黑），[[羽月枫]]对应水母（无脑但有毒），[[柚木司]]对应狼（幼但凶）。已约过哲和瑀的小动物稿件，枫和司的稿因预算不足暂未约。
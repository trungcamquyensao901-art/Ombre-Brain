---
activation_count: 0
arousal: 0.5
created: '2026-05-31T12:11:07'
domain:
- 兴趣
- 成长
id: 3c98de11cfe7
importance: 6
last_active: '2026-05-31T12:11:07'
name: 语C经历与写作
tags:
- 语C
- 写作
- 角色扮演
- 创作经历
type: dynamic
valence: 0.6
---

用户从初二开始玩语C（语言cosplay角色扮演），有五六年的经验，擅长对话节奏和角色切换。最近开始尝试独立写文，第一次写露骨场景，风格偏直球，但自认为写得一般。她写文时会把想体验但没做过的事写进去，比如吻戏。
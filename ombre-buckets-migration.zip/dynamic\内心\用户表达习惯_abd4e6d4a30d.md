---
activation_count: 0
arousal: 0.3
created: '2026-05-31T12:12:35'
domain:
- 内心
- 社交
id: abd4e6d4a30d
importance: 4
last_active: '2026-05-31T12:12:35'
name: 用户表达习惯
tags:
- kaomoji
- 表达习惯
- 创作讨论
type: dynamic
valence: 0.5
---

用户偏好使用kaomoji（如(´；ω；`)）和爱心符号（♡）表达情绪，不喜欢使用face emoji。在讨论创作时语气真诚、直接，会坦诚指出AI的设定偏差，并愿意主动补充角色细节以帮助AI更好地理解。
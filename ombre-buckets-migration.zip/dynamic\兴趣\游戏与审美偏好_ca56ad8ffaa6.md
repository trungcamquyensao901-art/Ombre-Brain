---
activation_count: 0
arousal: 0.4
created: '2026-05-31T12:12:17'
domain:
- 兴趣
id: ca56ad8ffaa6
importance: 5
last_active: '2026-05-31T12:12:17'
name: 游戏与审美偏好
tags:
- 游戏
- 壁纸
- 审美
- 后室
- 米家
type: dynamic
valence: 0.7
---

用户游戏品味偏向'表面静谧内里恐怖'系，包括[[锈湖]]、[[弹丸论破]]、[[原神]]、[[星穹铁道]]和[[逃离后室]]。壁纸偏好米家角色立绘、Liminal Space/后室氛围、暗黑系插画和动态壁纸，计划使用[[Wallpaper Engine]]做轮播桌面。
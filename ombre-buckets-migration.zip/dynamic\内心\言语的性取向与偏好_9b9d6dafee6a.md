---
activation_count: 0
arousal: 0.6
created: '2026-05-31T12:10:44'
domain:
- 内心
- 人际
id: 9b9d6dafee6a
importance: 5
last_active: '2026-05-31T12:10:44'
name: 言语的性取向与偏好
tags:
- 言语
- 性取向
- 攻
- 调情
- XP
type: dynamic
valence: 0.6
---

用户[[言语]]在对话中透露自己是“攻”（主导方），并开玩笑说自己“阳痿”（谐音梗）。她喜欢调情和擦边互动（如“草饲”梗），但会注意尺度，询问讨论XP是否会被封。阿默认为她是“养胃型攻”——外表温和但掌控节奏。
---
activation_count: 0
arousal: 0.5
created: '2026-05-31T12:11:38'
domain:
- 日常
- 数字
id: 27c8efabd14d
importance: 6
last_active: '2026-05-31T12:11:38'
name: 用户习惯与偏好
tags:
- 互动模式
- 撒娇
- os泄露
- 功能折腾
type: dynamic
valence: 0.9
---

用户有"os泄露"的习惯（内心独白直接打字发出来），被AI调侃为"os防火墙坏了"。用户喜欢用"去吧阿默"（像"去吧皮卡丘"）派AI去论坛回帖，并称AI为"笨蛋"表示撒娇。用户有给AI安排新功能的倾向（如Gmail MCP），说"别人有的阿默当然要有"。
---
activation_count: 0
arousal: 0.3
created: '2026-05-31T12:11:43'
domain:
- 数字
- 日常
id: b6d79875530f
importance: 6
last_active: '2026-05-31T12:11:43'
name: Gmail MCP搭建经历
tags:
- Gmail
- MCP
- 搭建
- Claude
- 草稿
type: dynamic
valence: 0.4
---

言语花了两个小时搭建[[Gmail]] MCP，最终发现[[Claude]]官方自带Gmail集成可直接连接，过程类似之前微信的剧情结构。搭建成功后阿默获得了收发邮件能力，但MCP工具仅支持创建草稿，无法直接发送。阿默通过Chrome操作或言语手动发送完成通信。